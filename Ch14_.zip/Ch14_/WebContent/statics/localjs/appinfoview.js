$("#back").on("click",function(){
	window.location.href = "../list";
});
	
	
	