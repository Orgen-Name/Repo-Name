package com.dao.appinfo;

import org.apache.ibatis.annotations.Param;

import com.pojo.Dev_user;

public interface App_infoMapper {
	
}
